class PagesController < ApplicationController
  def home
  end

  def replace_with_path
  	json = File.open(params[:params_path]).read 
	  params_hash = eval(json)

    doc = Gutenberg::Docx.new(params[:file_path], params_hash)
    doc.generate("tmp/output_document.docx")

  	doc_read = File.open("tmp/output_document.docx").read

  	send_data(doc_read, 
	    :filename    => "output_document.docx", 
	    :disposition => 'attachment') 
  end

  def replace_with_file
    
    json = File.open(params[:params_file].tempfile.path).read
    params_hash = eval(json)

  	doc = Gutenberg::Docx.new(params[:file].tempfile, params_hash)
  	doc.generate("tmp/output_document.docx")

  	doc_read = File.open("tmp/output_document.docx").read

  	send_data(doc_read, 
	    :filename    => "output_document.docx", 
	    :disposition => 'attachment') 
  end
end