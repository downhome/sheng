# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AppGutenberg::Application.config.secret_token = 'a069dad4e1dbc0776b710a882241934643460831b55e669eecb6861026479e46c4726e181e63755a8ee17765f047cee65750f98706f9ce0d62757aa729569d7e'
